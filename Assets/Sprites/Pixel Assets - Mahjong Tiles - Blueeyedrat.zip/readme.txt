Pixel Assets - Mahjong Tiles

Created by Blueeyedrat - https://blueeyedrat.itch.io

Last updated: 2021-06-19

-

Contents:

deck_mahjong_light_0.png
deck_mahjong_light_1.png
deck_mahjong_light_alts.png
deck_mahjong_dark_0.png
deck_mahjong_dark_1.png
deck_mahjong_dark_alts.png
deck_mahjong_backs.png
palette_mahjong.png

-

You may use and modify these assets for commercial and non-commercial projects. Credit is not required, but is encouraged and appreciated. You may not re-package, re-distribute, nor re-sell these assets, no matter how much they are modified.